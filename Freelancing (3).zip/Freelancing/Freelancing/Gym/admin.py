from django.contrib import admin

# Register your models here.
from .models import *
admin.site.register(Signup)
admin.site.register(Login)
admin.site.register(UserProfile)

admin.site.register(Staff)

