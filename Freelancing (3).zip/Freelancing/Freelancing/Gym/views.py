from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login ,logout
from django.contrib import messages
from .models import Signup,UserProfile
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required,user_passes_test
from django.shortcuts import render, get_object_or_404, redirect
from django.core.exceptions import ObjectDoesNotExist
from .forms import WorkoutForm
from .models import Workout

# Create your views here.
def welcome(request):
    if request.method=="GET":
        return render(request,"Home.html")
def Home(request):
    if request.method=="GET":
        return render(request,"Home.html")
    
def programs(request):
    if request.method=='GET':
        return render(request,"program.html")

def membership(request):
    if request.method=='GET':
        return render(request,"membership.html")

def Contact(request):
    if request.method=='GET':
        return render(request,"Contact.html")

def avail(request): 
    if request.method=='GET':
        return render(request,"avail.html")

def user_login(request):
    if request.method=='GET':
        return render(request,"login.html")
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        print(username,password)
        user=authenticate(request,username=username,password=password)
        print(user)
        if user is not None:
            login(request,user)
            messages.success(request,"Login successful")
            return redirect("payment_gateway")
        else:
            messages.error(request,"Invalid username or password")
            print("Login failed")
            
            return render(request,"login.html")
def signup(request):
    if request.method=='GET':    
        return render(request,"signup.html")
    if request.method=='POST':
        username=request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('password')
        print(request.POST)
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken")
            return redirect("signup")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
            return redirect("signup")
        user=User.objects.create(username=username,email=email,password=password)
        
        user.set_password(password)        
        user_profile = UserProfile.objects.create(user=user)
        user_profile.save()
        
        messages.success(request, "Registration successful")
        return redirect("login")
    return render(request,"signup.html")
def payment_gateway(request):
    if request.method=='GET':
        return render(request,"payment_gateway.html")

def message(request):
    if request.method=='GET':
        return render(request,"message.html")

@login_required
def process_payment(request):
    if request.method == 'POST':
        amount = int(request.POST.get('amount'))
        user_profile = UserProfile.objects.get(user=request.user)
        print(amount,user_profile)       
        
        if amount == 30:
            user_profile.activemembership = 'Basic'
        elif amount == 50:
            user_profile.activemembership = 'Standard'
        elif amount == 70:
            user_profile.activemembership = 'Premium'
        else:
            messages.error(request, "Invalid payment amount.")
            return redirect('payment_gateway')

        user_profile.save()
        messages.success(request, f"Membership updated to {user_profile.activemembership}!")
        return redirect('dashboard')

    return render(request, 'payment_gateway.html')
def dashboard(request):
    if request.user.is_authenticated:
        try:
            
            user_profile = UserProfile.objects.get(user=request.user)
        except ObjectDoesNotExist:
            
            user_profile = None  

        return render(request, "dashboard.html", {"user_profile": user_profile})
    else:
        messages.error(request, "You are not logged in.")
        return redirect('login')

def custom_login_required(view_func):
    
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.error(request, "You need to log in first.")
            return redirect("login") 


        if not request.user.is_staff:
            messages.error(request, "You have to be a staff member to insert data.")
            return redirect("home")  
        
        return view_func(request, *args, **kwargs)
    
    return wrapper
@login_required
def insert(request):
    print(" Request method:", request.method)
    print(" Request POST data:", request.POST)

    if request.method == 'POST':
        try:
            username = request.POST.get('username', '').strip()
            name = request.POST.get('name', '').strip()
            age = request.POST.get('age', '').strip()
            phonenumber = request.POST.get('Phonenumber', '').strip()

            print(" Received username:", username)

            if not username or not name or not age or not phonenumber:
                messages.error(request, "All fields are required.")  
                print(" Error: Missing fields") 
                return redirect("insert")

            if not phonenumber.isdigit() or len(phonenumber) != 10:
                messages.error(request, "Invalid phone number.")
                print(" Error: Invalid phone number")  
                return redirect("insert")

            if User.objects.filter(username=username).exists():
                messages.error(request, "A user with this username already exists.")
                print(" Error: Duplicate username")  
                return redirect("insert")

            new_user = User.objects.create_user(username=username, password="defaultpassword")
            print(" New user created:", new_user)

            user_profile = UserProfile.objects.create(
                user=new_user,
                name=name,
                Age=age,
                phonenumber=phonenumber
            )
            print(" New user profile created:", user_profile)

            messages.success(request, "New user profile created successfully.")
            return redirect("membership")

        except Exception as e:
            print(" Exception Occurred:", str(e))
            messages.error(request, f"Error: {str(e)}")
            return redirect("insert")

    return render(request, "insert.html")

def delete(request,username):
    username=User.objects.get(username=username)
    print(username)
    username.delete()
    return HttpResponse("Deleted")

def update(request, username):
    
    user_profile = get_object_or_404(UserProfile, user__username=username)

    if request.method == 'GET':
        return render(request, "update.html", {"user_profile": user_profile})

    if request.method == 'POST':
        request.session['update_data'] = {
            'name': request.POST.get('name'),
            'age': request.POST.get('age'),
            'phonenumber': request.POST.get('Phonenumber'),
            'membership': request.POST.get('membership'),
            'username': username
        }
        return redirect('payment')  

    return redirect('home')

def getdata(request, username):
    user = get_object_or_404(User, username=username)  
    
    context = {
        "user": user,
        "user_profile": user.userprofile,  
    }
    
    return render(request, "userdetails.html", context)
def staff(request):
    users = User.objects.all()  
    return render(request, "staff.html", {"users": users})

def user_logout(request):
    logout(request)
    return redirect("home")
def is_admin(user):
    return user.is_superuser

def workout_list(request):
    workouts = Workout.objects.all()
    if request.method == "POST":
        form = WorkoutForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('workout_list')
    else:
        form = WorkoutForm()
    return render(request, 'workout_list.html', {'workouts': workouts, 'form': form})

def update_workout(request, id):
    workout = get_object_or_404(Workout, id=id)
    if request.method == "POST":
        form = WorkoutForm(request.POST, instance=workout)
        if form.is_valid():
            form.save()
            return redirect('workout_list')
    else:
        form = WorkoutForm(instance=workout)
    return render(request, 'update_workout.html', {'form': form})

def delete_workout(request, id):
    workout = get_object_or_404(Workout, id=id)
    workout.delete()
    return redirect('workout_list')