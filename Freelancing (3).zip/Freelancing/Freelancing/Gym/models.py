from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Signup(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=100)
    

    def __str__(self):
        return self.name
class Login(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100) 

class Staff(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
class Workout(models.Model):
    id=models.AutoField(primary_key=True)
    exercise=models.CharField(max_length=100)

class UserProfile(models.Model):
    id=models.AutoField(primary_key=True)
    user=models.OneToOneField(User, on_delete=models.CASCADE,null=False)
    name=models.CharField(max_length=100,default="null")
    Age=models.IntegerField(default=0)
    phonenumber=models.CharField(max_length=10,default=0)
    activemembership=models.CharField(max_length=100,default="No membership")
    def __str__(self):
        return f"{self.user.username} - {self.activemembership}"
class Contactinfo(models.Model):
    customername=models.CharField(max_length=100)
    email=models.EmailField()
    phonenumber=models.CharField(max_length=10)

    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE) 