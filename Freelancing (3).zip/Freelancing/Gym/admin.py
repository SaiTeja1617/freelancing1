from django.contrib import admin

# Register your models here.
from .models import *
admin.site.register(Signup)
admin.site.register(Login)
admin.site.register(UserProfile)
admin.site.register(Workout)
class WorkoutAdmin(admin.ModelAdmin):
    list_display = ('id', 'exercise')
admin.site.register(Staff)

