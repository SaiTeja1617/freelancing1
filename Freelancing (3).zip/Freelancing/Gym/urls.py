from django.urls import path,include
from .import views
from .views import workout_list, update_workout, delete_workout,insert_workout
from django.contrib.auth import views as auth_views




urlpatterns=[
    
    path('',views.avail,name='avail'),
    path('/home',views.Home,name='home'),

    path('/Home',views.Home,name='home'),
    path("/programs",views.programs,name='programs'),
    path("/membership",views.membership,name='membership'),
    path('/contact',views.Contact,name='contact'),
    
    path('/login',views.user_login,name='login'),
    path('/signup',views.signup,name='signup'),
    path('/payment_gateway',views.payment_gateway,name='payment_gateway'),
    path('/message',views.message,name='message'),
    path('/payment',views.process_payment,name='payment'),
    path('/dashboard',views.dashboard,name='dashboard'),
    path("/insert",views.insert,name="insert"),
    path('/accounts/profile/', views.CustomLoginView.as_view(), name='login'),
    path('/delete/<str:username>/',views.delete,name='delete'),
    path('/update/<str:username>/',views.update,name='update'),
    path('/getdata/<str:username>/',views.getdata,name='getdata'),
    path('/staff',views.staff,name='staff'),
    path('/gym/staff',views.staff,name='staff'),
    path("/process_payment", views.process_payment, name="process_payment"),
    path('/gym/membership',views.membership,name='membership'),
    path('/gym/avail',views.avail,name='avail'),
    path('/gym/login',views.user_login,name='login'),
    path('/gym/signup',views.signup,name='signup'),
    path('/gym/payment_gateway',views.payment_gateway,name='payment_gateway'),
    path('/logout',views.user_logout,name='logout'),
    path('/select',views.payment_gateway,name='payment_gateway'),
    path('/gym/select',views.payment_gateway,name='payment_gateway'),
    path('/gym/logout',views.user_logout,name='logout'),
    path('/gym/home',views.Home,name='home'),
    path('/workouts', workout_list, name='workout_list'),#staff to view all workouts 
    path('/workouts/update/<int:id>/', update_workout, name='update_workout'),#staff to update workout
    path('/Gym/workouts', insert_workout, name='insert_workout'),#staff to viel all  workout
    path('/workouts/delete/<int:id>/', delete_workout, name='delete_workout'),#staff to delete workout
    path('accounts/', include('django.contrib.auth.urls')),
    path('accounts/logout/', views.custom_logout, name='logout'),
    
    
    path('accounts/login/', auth_views.LoginView.as_view(template_name='Gym/registration/login.html'), name='login'),
    
]