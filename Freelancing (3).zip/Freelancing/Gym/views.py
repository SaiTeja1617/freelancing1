from django.contrib.auth.views import LoginView
from django.conf import settings
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login ,logout
from django.urls import reverse
from django.contrib import messages
from .models import Signup,UserProfile
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required,user_passes_test
from django.shortcuts import render, get_object_or_404, redirect
from django.core.exceptions import ObjectDoesNotExist
from .forms import WorkoutForm
from .models import Workout
import logging
from functools import wraps

# Create your views here.
def welcome(request):
    if request.method=="GET":
        return render(request,"Home.html")
@login_required
def Home(request):
    if request.method=="GET":
        return render(request,"Home.html")

@login_required 
def programs(request):
    if request.method=='GET':
        return render(request,"program.html")
@login_required
def membership(request):
    if request.method=='GET':
        return render(request,"membership.html")
@login_required
def Contact(request):
    if request.method=='GET':
        return render(request,"Contact.html")

def avail(request): 
    if request.method=='GET':
        return render(request,"avail.html")

def user_login(request):
    if request.method=='GET':
        return render(request,"login.html")
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        print(username,password)
        user=authenticate(request,username=username,password=password)
        print(user)
        if user is not None:
            login(request,user)
            messages.success(request,"Login successful")
            if user.is_staff:
                return redirect(reverse("insert"))
            if user.is_superuser:
                return redirect(reverse("gym/workout_list"))
               
            return redirect(reverse("membership"))
        else:
            messages.error(request,"Invalid username or password")
            print("Login failed")
            
            return render(request,"login.html")
def signup(request):
    if request.method=='GET':    
        return render(request,"signup.html")
    if request.method=='POST':
        username=request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('password')
        print(request.POST)
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken")
            return redirect("signup")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
            return redirect("signup")
        user=User(username=username,email=email)
        user.set_password(password)        
        user.save()
        
        user_profile = UserProfile.objects.create(user=user)
        
        user_profile.save()
        
        messages.success(request, "Registration successful")
        return redirect(reverse("login"))
    return render(request,"signup.html")
@login_required
def payment_gateway(request):
    if request.method=='GET':
        return render(request,"payment_gateway.html")
@login_required
def message(request):
    if request.method=='GET':
        return render(request,"message.html")

@login_required
def process_payment(request):
    print("process_payment function is being called.")
    logging.debug("process_payment function is being called.")
    if request.method == 'POST':
        logging.debug(f"Request Data: {request.POST}")
        
        
        logging.debug(f"Before Update: {user_profile.activemembership}")
        
        user_profile = UserProfile.objects.get(user=request.user)
        amount = int(request.POST.get('amount'))
        if not amount:
            logging.debug("ERROR: 'amount' is missing in request.POST")
            messages.error(request, "Amount is required.")
            return redirect('payment_gateway')
        try:
            amount = int(amount)
        except ValueError:
            logging.debug("ERROR: Amount is not a valid number.")
            messages.error(request, "Invalid payment amount.")
            return redirect('payment_gateway')
        
        
        
        
        print(amount,user_profile)       
        
        if amount == 30:
            user_profile.activemembership = 'basic'
            
        elif amount == 50:
            user_profile.activemembership = 'standard'
            
        elif amount == 70:
            user_profile.activemembership = 'premium'
            
        else:
            messages.error(request, "Invalid payment amount.")
            return redirect('payment_gateway')

        user_profile.save()

        user_profile.refresh_from_db()
        logging.debug(f"After Update: {user_profile.activemembership}")
        messages.success(request, f"Membership updated to {user_profile.activemembership}!")
        return redirect('Payment_gateway.html')

    return render(request, 'payment_gateway.html')
def dashboard(request):
    if request.user.is_authenticated:
        try:
            
            user_profile = UserProfile.objects.get(user=request.user)
        except ObjectDoesNotExist:
            
            user_profile = None  

        return render(request, "dashboard.html", {"user_profile": user_profile})
    else:
        messages.error(request, "You are not logged in.")
        return redirect('login')

# def custom_login_required(view_func):
    
#     def wrapper(request, *args, **kwargs):
#         if not request.user.is_authenticated:
#             messages.error(request, "You need to log in first.")
#             return redirect("login") 


#         if not request.user.is_staff:
#             messages.error(request, "You have to be a staff member to insert data.")
#             return redirect("home")  
        
#         return view_func(request, *args, **kwargs)
    
#     return wrapper
def custom_login_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.error(request, "You need to log in first.")
            return redirect("login")

        if not request.user.is_staff:
            messages.error(request, "You have to be a staff member to insert data.")
            return redirect("home")

        
        return view_func(request, *args, **kwargs)

    return wrapper
@custom_login_required

def insert(request):    
    if not request.user.is_staff:  
        messages.error(request, "Only staff users can insert data.")
        return redirect("home")  

    if request.method == "POST":
        username = request.POST.get("username").strip()
        name = request.POST.get("name").strip()
        age = request.POST.get("age").strip()
        phonenumber = request.POST.get("Phonenumber").strip()
        activemembership = request.POST.get("activemembership").strip()

        if not username or not name or not age or not phonenumber:
            messages.error(request, "All fields are required.")
            return redirect("insert")

        if not phonenumber.isdigit() or len(phonenumber) != 10:
            messages.error(request, "Invalid phone number.")
            return redirect("insert")

        if User.objects.filter(username=username).exists():
            messages.error(request, "A user with this username already exists.")
            return redirect("insert")

        
        new_user = User.objects.create_user(username=username, password="defaultpassword")

        
        UserProfile.objects.create(
            user=new_user,
            name=name,
            Age=int(age),
            phonenumber=phonenumber,
            activemembership=activemembership
        )

        messages.success(request, "New user profile created successfully.")
        return redirect("membership")

    return render(request, "insert.html")

def delete(request,username):
    username=User.objects.get(username=username)
    print(username)
    username.delete()
    return redirect("staff")
    return HttpResponse("Deleted")


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import UserProfile

def update(request, username):
    user_profile = get_object_or_404(UserProfile, user__username=username)

    if request.method == 'GET':
        return render(request, "update.html", {"user_profile": user_profile})

    if request.method == 'POST':
        name = request.POST.get('name')
        age = request.POST.get('age')
        phonenumber = request.POST.get('Phonenumber')
        membership = request.POST.get('membership')

        
        user_profile.name = name
        user_profile.Age = age
        user_profile.phonenumber = phonenumber
        user_profile.activemembership = membership
        user_profile.save()

        messages.success(request, "User profile updated successfully.")

        return redirect('dashboard') 

    return redirect('home')

def getdata(request, username):
    user = get_object_or_404(User, username=username)  
    
    context = {
        "user": user,
        "user_profile": user.userprofile,  
    }
    
    return render(request, "userdetails.html", context)
def staff(request):
    users = User.objects.all()  
    return render(request, "staff.html", {"users": users})

def user_logout(request):
    logout(request)
    return redirect("home")
def is_admin(user):
    return user.is_superuser
def is_superuser(user):
    return user.is_authenticated and user.is_superuser
@user_passes_test(is_superuser, login_url='/accounts/login/')
@login_required(login_url='/accounts/login/') 

def workout_list(request):
    workouts = Workout.objects.all()
    return render(request, 'workout_list.html', {'workouts': workouts})

@user_passes_test(is_superuser, login_url='/accounts/login/')
@login_required(login_url='/accounts/login/')

def insert_workout(request):
    if request.method == "POST":
        exercise_name = request.POST.get("exercise")
        if exercise_name:
            Workout.objects.create(exercise=exercise_name)
            messages.success(request, "Workout added successfully.")
            return redirect("/Gym/workouts")
    
    workouts = Workout.objects.all()
    total_workouts = workouts.count()
    
    context = {
        "workouts": workouts,
        "total_workouts": total_workouts,
    }
    return render(request, "insert_workout.html", context)

@user_passes_test(is_superuser, login_url='/accounts/login/')
@login_required(login_url='/accounts/login/')

def update_workout(request, id):
    workout = get_object_or_404(Workout, id=id)
    if request.method == "POST":
        form = WorkoutForm(request.POST, instance=workout)
        if form.is_valid():
            form.save()
            return redirect('workout_list')
    else:
        form = WorkoutForm(instance=workout)
    return render(request, 'update_workout.html', {'form': form})
@user_passes_test(is_superuser, login_url='/accounts/login/')
@login_required(login_url='/accounts/login/')

def delete_workout(request, id):
    workout = get_object_or_404(Workout, id=id)
    workout.delete()
    return redirect('workout_list')
def process_payment(request):
    if request.method == "POST":
        
        amount = request.POST.get("amount")
        
        

        
        return redirect("dashboard")  

    return redirect("dashboard")    
class CustomLoginView(LoginView):
    def get_success_url(self):
        return "insert" 
    
def custom_logout(request):
    logout(request)
    return redirect('/accounts/login/')